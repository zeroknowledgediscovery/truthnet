#!/bin/bash

git rm *~
git rm *out
git rm *log
git rm *blg
git rm *bbl
git rm *toc
git rm *aux*
git rm *fls
git rm *latex*
git rm *~
git rm *out
git rm *log


rm *~
rm *out
rm *log
rm *fls
rm *aux
rm *auxlock
rm *latexmk
