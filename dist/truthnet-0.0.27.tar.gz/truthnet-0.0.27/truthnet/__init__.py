'''

# truthnet
      
Description:                                                                   
                                                                                
Detecting malingering in structured interviews
                                                                                                      
Installation:                                                                                               

```
pip install truthnet

```               
   Theory:                                                                                                                     

'''

from .truthnet import truthnet, train, load_veritas_model



