'''

# truthnet
      
Description:                                                                   
                                                                                
Detecting malingering in structured interviews
                                                                                                      
Installation:                                                                                               

```
pip install truthnet

```               
   Theory:                                                                                                                     

'''

from .truthnet import truthnet



